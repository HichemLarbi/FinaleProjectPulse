package com.example.hlarbi.app3.ViewClasses;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.hlarbi.app3.API.objects.ClassRequest.APIClient;
import com.example.hlarbi.app3.API.objects.ClassRequest.ServiceGenerator;
import com.example.hlarbi.app3.API.objects.Oauth.AccessToken;
import com.example.hlarbi.app3.BuildConfig;
import com.example.hlarbi.app3.MainClasses.MainActi.MainActivity;
import com.example.hlarbi.app3.Register_Classes.LoginActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.hlarbi.app3.Register_Classes.LoginActivity.API_LOGIN_URL;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.API_OAUTH_REDIRECT;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.base2;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.client_id;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.sqLiteHelper;

public class FitbitSynchronization extends AppCompatActivity {
    public static String code;
    final SQLiteDatabase db = sqLiteHelper.getReadableDatabase();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(API_LOGIN_URL + "&client_id=" + client_id + "&redirect_uri=" + API_OAUTH_REDIRECT + "&scope=activity&expired_in=604800"));
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
        finish();
    }
    @Override
    protected void onResume() {
        super.onResume();
        Uri uri = getIntent().getData();
        if(uri != null && uri.toString().startsWith(API_OAUTH_REDIRECT)) {
            String code = uri.getQueryParameter("code");
            if(code != null) {
                final SharedPreferences prefs = this.getSharedPreferences(
                        BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE);
                APIClient client = ServiceGenerator.createService(APIClient.class);
                Call<AccessToken> call = client.getNewAccessToken("authorization_code",
                        client_id,
                        API_OAUTH_REDIRECT,
                        code,
                        base2);
                call.enqueue(new Callback<AccessToken>() {
                    @Override
                    public void onResponse(final Call<AccessToken> call, Response<AccessToken> response) {
                        int statusCode = response.code();
                        if (statusCode == 200) {
                            final AccessToken token = response.body();
                            prefs.edit().putBoolean("oauth.loggedin", true).apply();
                            prefs.edit().putString("oauth.accesstoken", token.getAccessToken()).apply();
                            prefs.edit().putString("oauth.refreshtoken", token.getRefreshToken()).apply();
                            prefs.edit().putString("oauth.tokentype", token.getTokenType()).apply();
                            prefs.edit().putString("oauth.tokentype", token.getUser_ID()).apply();
                            String newheadertoken ="Bearer " + String.valueOf(token.getAccessToken());
                            String newusId = String.valueOf(token.getUser_ID());
                            String newrefresh= String.valueOf(token.getRefreshToken());
                            ContentValues cvToken = new ContentValues();
                            ContentValues cvUserId = new ContentValues();
                            ContentValues cvRefresh = new ContentValues();
                            cvToken.put("oauthnumber",newheadertoken);
                            cvUserId.put("oauthnumber",newusId);
                            cvRefresh.put("oauthnumber",newrefresh);
                            db.update("OAUTHTABLE", cvToken, "id = 1", null);
                            db.update("OAUTHTABLE", cvUserId, "id = 2", null);
                            db.update("OAUTHTABLE", cvRefresh, "id = 3", null);
                            Intent intent = new Intent(FitbitSynchronization.this, MainActivity.class);
                            startActivity(intent);
                        }
                    }
                    @Override
                    public void onFailure(Call<AccessToken> call, Throwable t) {
                    }
                }); } }

    }
}

