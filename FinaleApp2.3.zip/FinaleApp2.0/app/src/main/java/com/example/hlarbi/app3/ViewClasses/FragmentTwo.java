package com.example.hlarbi.app3.ViewClasses;
/*FragmentTwo : display data from Pollution Table in a GridView and has a button to open linechart activity.
* NB : linechart operates but API AQIC to not provide a forecast of the aqi*/
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import com.example.hlarbi.app3.MainClasses.FragTwo.PolluListAdapter;
import com.example.hlarbi.app3.MainClasses.FragTwo.Pollution;
import com.example.hlarbi.app3.R;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.sqLiteHelper;
public class FragmentTwo extends Fragment{
    public static int f = 0;

    final SQLiteDatabase db = sqLiteHelper.getReadableDatabase();
    ArrayList<Pollution> list;
    PolluListAdapter adapter;
    TextView aqiTextView;
    Button barca;
    Button birmin;
    Button NYC;
    Button paris;
    Button singapore;
    DialogCitybis dialogCitybis;
    public FragmentTwo()  {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)  {
        // Inflate the layout for this fragment
        final View pollu_view = inflater.inflate(R.layout.activity_data_pollution, container, false);
        final Button spinner_city = (Button) pollu_view.findViewById(R.id.spinner_choose_city);
        ////////////////////AQI//////////////////////
/////////////////////////////////SET AQI//////////////////////////////////////////
        Cursor caqi = db.rawQuery("SELECT * FROM AQITABLE WHERE id = 1", null);
        caqi.moveToFirst();
        final String aqi = String.valueOf(caqi.getString(caqi.getColumnIndex("aqinumber")));
        aqiTextView = pollu_view.findViewById(R.id.textAqiView);
        aqiTextView.setText(aqi);
/////////////////////////////////SET AQI//////////////////////////////////////////

        ///////////////////////////////////SET CITY///////////////////////////
        Cursor ccity = db.rawQuery("SELECT * FROM AQITABLE WHERE id = 2", null);
        ccity.moveToFirst();
        final String cityupdate = String.valueOf(ccity.getString(ccity.getColumnIndex("aqinumber")));

        Button b = (Button) pollu_view.findViewById(R.id.popup);
        b.setText(cityupdate);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(getContext(), PopLineChartPollu.class)));
            }
        });
        GridView ls = (GridView) pollu_view.findViewById(R.id.grid_view_data_pollu);
        list = new ArrayList<>();
        adapter = new PolluListAdapter(getContext(), R.layout.item_sample_gridview_pollu, list);
        ls.setAdapter(adapter);
        Cursor cursor = sqLiteHelper.getData("SELECT * FROM POLLUTABLE");
        list.clear();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String fullname = cursor.getString(1);
            String polluname = cursor.getString(2);
            String pollunumber = cursor.getString(3);
            list.add(new Pollution(fullname, polluname, pollunumber, id));
        }
        adapter.notifyDataSetChanged();

        // Inflate the layout for this fragment


        spinner_city.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                View cityview = getLayoutInflater().inflate(R.layout.activity_dialogue_city,null);
                barca = (Button)cityview.findViewById(R.id.Barcelonabtn);
                birmin = (Button)cityview.findViewById(R.id.Birminghambtn);
                NYC = (Button)cityview.findViewById(R.id.NewYorkCitybtn);
                paris = (Button)cityview.findViewById(R.id.Parisbtn);
                singapore = (Button)cityview.findViewById(R.id.Singaporebtn);
                builder.setView(cityview);
                final AlertDialog dialog = builder.create();
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.show();


                barca.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ContentValues cvCity = new ContentValues();
                        cvCity.put("aqinumber","Barcelona");
                        db.update("AQITABLE", cvCity, "id = 2", null);
                        String[] abrev1 = {"so2","no2","o3","pm10","p","t"};
                        String[] name1 = {"SO2","NO2","O3","PM10","P","C°"};
                        String[] fullname1 = {"Sulfur Dioxyde","Azote Dioxyde","Ozone","Particulate Matter 10","Pressure","Temperature"};
                        updateall("41.390205;2.154007",fullname1,name1,abrev1,"Barcelona");
                        dialog.dismiss();
                        f=f+1;


                    }
                });
                birmin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ContentValues cvCity = new ContentValues();
                        cvCity.put("aqinumber","Birmingham");
                        db.update("AQITABLE", cvCity, "id = 2", null);
                        String[] abrev2 = {"o3","no2","pm10","pm25","p","t"};
                        String[] name2 = {"O3","NO2","PM10","PM25","P","C°"};
                        String[] fullname2 = {"Ozone","Azote Dioxyde","Particulate Matter","Particulate Matter 2,5","Pressure","Temperature"};
                        updateall("52.489471;-1.898575",fullname2,name2,abrev2,"Birmingham");
                        dialog.dismiss();
                    }
                });
                NYC.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ContentValues cvCity = new ContentValues();
                        cvCity.put("aqinumber","New York City");
                        db.update("AQITABLE", cvCity, "id = 2", null);
                        String[] abrev3 = {"co","no2","o3","pm25","p","h"};
                        String[] name3 = {"CO","NO2","O3","PM25","P","H"};
                        String[] fullname3 = {"Carbon Monoxyde","Azote Dioxyde","Ozone","Particulate Matter 2,5","Pressure","Humidity"};
                        updateall("40.730610;-73.935242",fullname3,name3,abrev3,"New York City");
                        dialog.dismiss();
                    }
                });
                paris.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ContentValues cvCity = new ContentValues();
                        cvCity.put("aqinumber","Paris");
                        db.update("AQITABLE", cvCity, "id = 2", null);
                        String[] abrev4 = {"co","no2","o3","so2","pm10","pm25"};
                        String[] name4 = {"CO","NO2","O3","SO2","PM10","PM25"};
                        String[] fullname4 = {"Carbon Monoxyde","Azote Dioxyde","Ozone","Sulfur Dioxyde","Particulate Mattere 10","Particulate Matter 2,5"};
                        updateall("48.856614;2.3522219",fullname4,name4,abrev4,"Paris");
                        dialog.dismiss();
                    }
                });
                singapore.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ContentValues cvCity = new ContentValues();
                        cvCity.put("aqinumber","Singapore");
                        db.update("AQITABLE", cvCity, "id = 2", null);
                        String[] abrev5 = {"co","no2","o3","pm10","pm25","p"};
                        String[] name5 = {"CO","NO2","O3","PM10","PM25","P"};
                        String[] fullname5 = {"Carbon Monoxyde","Azote Dioxyde","Ozone","Particulate Matter 10","Particulate Mattere 25","Pressure"};
                        updateall("1.296568;103.852119",fullname5,name5,abrev5,"Singapore");

                        dialog.dismiss();
                    }
                });


            }
        });


        return pollu_view;
    }


    public void  updateall (final String latlog, String[] fullname, final String [] name, final String [] abrev, final String city){
        final SQLiteDatabase db = sqLiteHelper.getWritableDatabase();
        final String[] abrestr = abrev;
        final String[] namestr = name;
        final String[]fullnamestr =fullname;
        int i=0;
        while(i<2) {
            AsyncHttpClient client = new AsyncHttpClient();

            client.get("https://api.waqi.info/feed/geo:"+latlog+"/?token=c7cb1dd08fbca3cd163693d2d79efd9660a8e9a0&lat&lng&optional", null, new JsonHttpResponseHandler() {


                @Override
                public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, JSONObject response) {
                    try {
                        JSONObject data = response.getJSONObject("data");
                        String aqinumber = data.get("aqi").toString();
                        JSONObject iaqui = data.getJSONObject("iaqi");
                        String[] number_pollu = new String[]{
                                iaqui.getJSONObject(abrestr[0]).get("v").toString(),
                                iaqui.getJSONObject(abrestr[1]).get("v").toString(),
                                iaqui.getJSONObject(abrestr[2]).get("v").toString(),
                                iaqui.getJSONObject(abrestr[3]).get("v").toString(),
                                iaqui.getJSONObject(abrestr[4]).get("v").toString(),
                                iaqui.getJSONObject(abrestr[5]).get("v").toString(),
                        };
                        ///////////////////////////////number//////////////////////////////////////
                        ContentValues cvCO = new ContentValues();
                        ContentValues cvNO2 = new ContentValues();
                        ContentValues cvO3 = new ContentValues();
                        ContentValues cvSO2 = new ContentValues();
                        ContentValues cvPM10 = new ContentValues();
                        ContentValues cvPM25 = new ContentValues();


                        cvCO.put("pollunumber",number_pollu[0]);
                        cvNO2.put("pollunumber",number_pollu[1]);
                        cvO3.put("pollunumber",number_pollu[2]);
                        cvSO2.put("pollunumber",number_pollu[3]);
                        cvPM10.put("pollunumber",number_pollu[4]);
                        cvPM25.put("pollunumber",number_pollu[5]);


                        db.update("POLLUTABLE", cvCO, "id = 1", null);
                        db.update("POLLUTABLE", cvNO2, "id = 2", null);
                        db.update("POLLUTABLE", cvO3, "id = 3", null);
                        db.update("POLLUTABLE", cvSO2, "id = 4", null);
                        db.update("POLLUTABLE", cvPM10, "id = 5", null);
                        db.update("POLLUTABLE", cvPM25, "id = 6", null);


                        ///////AQI///////////
                        ContentValues cvAQI = new ContentValues();
                        ContentValues cvCity = new ContentValues();
                        ContentValues cvLatLog = new ContentValues();
                        cvAQI.put("aqinumber",aqinumber);
                        cvCity.put("aqinumber",city);
                        cvLatLog.put("aqinumber",latlog);
                        db.update("AQITABLE", cvAQI, "id = 1", null);
                        db.update("AQITABLE", cvCity, "id = 2", null);
                        db.update("AQITABLE",cvLatLog,"id = 3",null);
                        ////////AQI///////////
                        /////////////////////////////////name/////////////////////////////////////////////
                        ContentValues cvCOn = new ContentValues();
                        ContentValues cvNO2n = new ContentValues();
                        ContentValues cvO3n = new ContentValues();
                        ContentValues cvSO2n = new ContentValues();
                        ContentValues cvPM10n = new ContentValues();
                        ContentValues cvPM25n = new ContentValues();


                        cvCOn.put("polluname",namestr[0]);
                        cvNO2n.put("polluname",namestr[1]);
                        cvO3n.put("polluname",namestr[2]);
                        cvSO2n.put("polluname",namestr[3]);
                        cvPM10n.put("polluname",namestr[4]);
                        cvPM25n.put("polluname",namestr[5]);


                        db.update("POLLUTABLE", cvCOn, "id = 1", null);
                        db.update("POLLUTABLE", cvNO2n, "id = 2", null);
                        db.update("POLLUTABLE", cvO3n, "id = 3", null);
                        db.update("POLLUTABLE", cvSO2n, "id = 4", null);
                        db.update("POLLUTABLE", cvPM10n, "id = 5", null);
                        db.update("POLLUTABLE", cvPM25n, "id = 6", null);
                        //////////////////////////////name/////////////////////////////////////////////

                        //////////////////////////////fullname/////////////////////////////////////////////
                        ContentValues cvCOnf = new ContentValues();
                        ContentValues cvNO2nf = new ContentValues();
                        ContentValues cvO3nf = new ContentValues();
                        ContentValues cvSO2nf = new ContentValues();
                        ContentValues cvPM10nf = new ContentValues();
                        ContentValues cvPM25nf = new ContentValues();


                        cvCOnf.put("fullname",fullnamestr[0]);
                        cvNO2nf.put("fullname",fullnamestr[1]);
                        cvO3nf.put("fullname",fullnamestr[2]);
                        cvSO2nf.put("fullname",fullnamestr[3]);
                        cvPM10nf.put("fullname",fullnamestr[4]);
                        cvPM25nf.put("fullname",fullnamestr[5]);


                        db.update("POLLUTABLE", cvCOnf, "id = 1", null);
                        db.update("POLLUTABLE", cvNO2nf, "id = 2", null);
                        db.update("POLLUTABLE", cvO3nf, "id = 3", null);
                        db.update("POLLUTABLE", cvSO2nf, "id = 4", null);
                        db.update("POLLUTABLE", cvPM10nf, "id = 5", null);
                        db.update("POLLUTABLE", cvPM25nf, "id = 6", null);
                        //////////////////////////////fullname/////////////////////////////////////////////
                    } catch (JSONException e) {
                    }
                }
            });
            i+=1;
        }
    }
}