package com.example.hlarbi.app3.API.objects.ProfileUserFitbit;

import java.util.List;

public class ProfileUserFitbit {


    public List<ProfileContent> getUser() {
        return user;
    }

    public void setUser(List<ProfileContent> user) {
        this.user = user;
    }

    private List<ProfileContent> user = null;


}
