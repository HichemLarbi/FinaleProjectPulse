package com.example.hlarbi.app3.ViewClasses;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.hlarbi.app3.API.objects.ClassRequest.APIClient;
import com.example.hlarbi.app3.API.objects.ClassRequest.ServiceGenerator;
import com.example.hlarbi.app3.API.objects.Oauth.AccessToken;
import com.example.hlarbi.app3.BuildConfig;
import com.example.hlarbi.app3.MainClasses.MainActi.MainActivity;
import com.example.hlarbi.app3.R;
import com.example.hlarbi.app3.Register_Classes.LoginActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.hlarbi.app3.Register_Classes.LoginActivity.API_LOGIN_URL;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.API_OAUTH_REDIRECT;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.base2;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.client_id;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.client_secret;
import static com.example.hlarbi.app3.Register_Classes.LoginActivity.sqLiteHelper;

public class FitbitSynchronization extends AppCompatActivity {
    public static String code;
    String grant_type = "refresh_token";
    final SQLiteDatabase db = sqLiteHelper.getReadableDatabase();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_synchronisation);
        Cursor cheadertoken = db.rawQuery("SELECT * FROM OAUTHTABLE WHERE id = 1", null);
        cheadertoken.moveToFirst();
        final String headertoken  = String.valueOf(cheadertoken.getString(cheadertoken.getColumnIndex("oauthnumber")));
        Cursor cuserID = db.rawQuery("SELECT * FROM OAUTHTABLE WHERE id = 2", null);
        cuserID.moveToFirst();
        final String userIDUp  = String.valueOf(cuserID.getString(cuserID.getColumnIndex("oauthnumber")));
        Cursor crefresh = db.rawQuery("SELECT * FROM OAUTHTABLE WHERE id = 3", null);
        crefresh.moveToFirst();
        final String refresh  = String.valueOf(crefresh.getString(crefresh.getColumnIndex("oauthnumber")));
        APIClient client = ServiceGenerator.createService(APIClient.class,refresh,userIDUp,headertoken,this);
        Call<AccessToken> callrefresh = client.getRefreshAccessToken(refresh,
                client_id,
                client_secret,
                API_OAUTH_REDIRECT,
                grant_type);
        callrefresh.enqueue(new Callback<AccessToken>() {
            @Override
            public void onResponse(Call<AccessToken> call, Response<AccessToken> response) {
                int statusCode = response.code();
                if (statusCode == 200) {
                    AccessToken tokenUser_id1 = response.body();
                    String newheadertoken = "Bearer " + String.valueOf(tokenUser_id1.getAccessToken());
                    String newusId = String.valueOf(tokenUser_id1.getUser_ID());
                    String newrefresh = String.valueOf(tokenUser_id1.getRefreshToken());

                    ContentValues cvToken = new ContentValues();
                    ContentValues cvUserId = new ContentValues();
                    ContentValues cvRefresh = new ContentValues();
                    cvToken.put("oauthnumber", newheadertoken);
                    cvUserId.put("oauthnumber", newusId);
                    cvRefresh.put("oauthnumber", newrefresh);
                    db.update("OAUTHTABLE", cvToken, "id = 1", null);
                    db.update("OAUTHTABLE", cvUserId, "id = 2", null);
                    db.update("OAUTHTABLE", cvRefresh, "id = 3", null);
                    Toast.makeText(FitbitSynchronization.this,"Successfully synchronized",Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onFailure(Call<AccessToken> call, Throwable t) {
                Toast.makeText(FitbitSynchronization.this,"A problem appears during your synchronization",Toast.LENGTH_SHORT).show();
            }
        });

    }

}

