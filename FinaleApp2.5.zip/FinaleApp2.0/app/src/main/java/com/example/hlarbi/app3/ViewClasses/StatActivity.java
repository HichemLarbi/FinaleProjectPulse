package com.example.hlarbi.app3.ViewClasses;
/*Stat Activity : a barchart is display with data that are present in Stat SqLite Table. This class has a direct link to gridview adapter from FragmentOne :
when the user click on a gridview item such as Steps for instance, the click event update Stattable with steps forecast (from FitbitWeb Api) and then the Barchart open the activity and display the layout*/
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import com.example.hlarbi.app3.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import static com.example.hlarbi.app3.Register_Classes.LoginActivity.sqLiteHelper;
public class StatActivity extends AppCompatActivity {
    final SQLiteDatabase db = sqLiteHelper.getReadableDatabase();
    BarChart barChart;
    String[] listX ={"","","","","","",""};
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        long currMillis = System.currentTimeMillis();
        currMillis -= currMillis % TimeUnit.DAYS.toMillis(1);

    setContentView(R.layout.chart_bar_);
///////////////////////////////////////////TODAY STAT////////////////////////////////////////////////////////////
        Cursor cstat0 = db.rawQuery("SELECT * FROM STATTABLE WHERE id = 1", null);
        cstat0.moveToFirst();
        final Float stat0  = Float.valueOf(String.valueOf(cstat0.getString(cstat0.getColumnIndex("statnumber"))));
///////////////////////////////////////////TODAY STAT////////////////////////////////////////////////////////////

///////////////////////////////////////////TODAY STAT-1////////////////////////////////////////////////////////////
        Cursor cstat1 = db.rawQuery("SELECT * FROM STATTABLE WHERE id = 2", null);
        cstat1.moveToFirst();
        final Float stat1  = Float.valueOf(String.valueOf(cstat1.getString(cstat1.getColumnIndex("statnumber"))));
///////////////////////////////////////////TODAY STAT-1////////////////////////////////////////////////////////////

///////////////////////////////////////////TODAY STAT-2////////////////////////////////////////////////////////////
        Cursor cstat2 = db.rawQuery("SELECT * FROM STATTABLE WHERE id = 3", null);
        cstat2.moveToFirst();
        final Float stat2  = Float.valueOf(String.valueOf(cstat2.getString(cstat2.getColumnIndex("statnumber"))));
///////////////////////////////////////////TODAY STAT-2////////////////////////////////////////////////////////////

///////////////////////////////////////////TODAY STAT-3////////////////////////////////////////////////////////////
        Cursor cstat3 = db.rawQuery("SELECT * FROM STATTABLE WHERE id = 4", null);
        cstat3.moveToFirst();
        final Float stat3  = Float.valueOf(String.valueOf(cstat3.getString(cstat3.getColumnIndex("statnumber"))));
///////////////////////////////////////////TODAY STAT-3////////////////////////////////////////////////////////////

///////////////////////////////////////////TODAY STAT-4////////////////////////////////////////////////////////////
        Cursor cstat4 = db.rawQuery("SELECT * FROM STATTABLE WHERE id = 5", null);
        cstat4.moveToFirst();
        final Float stat4  = Float.valueOf(String.valueOf(cstat4.getString(cstat4.getColumnIndex("statnumber"))));
///////////////////////////////////////////TODAY STAT-4////////////////////////////////////////////////////////////

///////////////////////////////////////////TODAY STAT-5////////////////////////////////////////////////////////////
        Cursor cstat5 = db.rawQuery("SELECT * FROM STATTABLE WHERE id = 6", null);
        cstat5.moveToFirst();
        final Float stat5  = Float.valueOf(String.valueOf(cstat5.getString(cstat5.getColumnIndex("statnumber"))));
///////////////////////////////////////////TODAY STAT-5////////////////////////////////////////////////////////////

///////////////////////////////////////////TODAY STAT-6////////////////////////////////////////////////////////////
        Cursor cstat6 = db.rawQuery("SELECT * FROM STATTABLE WHERE id = 7", null);
        cstat6.moveToFirst();
        final Float stat6  = Float.valueOf(String.valueOf(cstat6.getString(cstat6.getColumnIndex("statnumber"))));
///////////////////////////////////////////TODAY STAT-6////////////////////////////////////////////////////////////
        barChart =(BarChart)findViewById(R.id.barchart);
        ArrayList<BarEntry> barEntries = new ArrayList<>();
        barEntries.add(new BarEntry(1,stat0));
        barEntries.add(new BarEntry(2,stat1));
        barEntries.add(new BarEntry(3,stat2));
        barEntries.add(new BarEntry(4,stat3));
        barEntries.add(new BarEntry(5,stat4));
        barEntries.add(new BarEntry(6,stat5));
        barEntries.add(new BarEntry(7,stat6));
        BarDataSet barDataSet = new BarDataSet(barEntries, "Days");
        barChart.setDrawGridBackground(false);
        barDataSet.setColors(THEMECOLORBLUE);
        BarData theData = new BarData(barDataSet);
        for (int i = 0; i < 7; i++) {
            long position = 7 - 1 - i;
            long offsetMillis = TimeUnit.DAYS.toMillis(position);
            long millis = currMillis - offsetMillis;
            int day = (int) millis/ (24 * 60 * 60 * 1000)+3;
            listX[i] = String.valueOf(day);
        }
        ArrayList xVals = new ArrayList();
        float barWidth;
        float barSpace;
        float groupSpace;

        barWidth = 0.4f;
        barSpace = 0f;
        groupSpace = 0.4f;

        xVals.add(listX[0]);
        xVals.add(listX[1]);
        xVals.add(listX[2]);
        xVals.add(listX[3]);
        xVals.add(listX[4]);
        xVals.add(listX[5]);
        xVals.add(listX[6]);
//X-axis
        XAxis xAxis = barChart.getXAxis();
        xAxis.setDrawGridLines(false);
        xAxis.setAxisMaximum(7);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xVals));
       barChart.setData(theData);   barChart.getAxisLeft().setDrawLabels(false);
        barChart.getAxisRight().setDrawLabels(false);barChart.getAxisLeft().setDrawGridLines(false);
        barChart.getAxisRight().setDrawGridLines(false);
        Legend l = barChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getBarData().setBarWidth(barWidth);
        barChart.getData().setHighlightEnabled(false);
        barChart.invalidate();
    /*     barChart.setTouchEnabled(true);
        barChart.setDragEnabled(true);
        barChart.setScaleEnabled(true);

       */
        barChart.animateY(2000);


        /*

        rgb(135,206,250)
rgb(135,206,235)
rgb(100,149,237)
rgb(70,130,180)
rgb(65,105,225)
rgb(25,25,112)
rgb(0,191,255)



        */
    }

    public static final int[] THEMECOLORBLUE = {
            Color.rgb(0, 18, 51),
            Color.rgb(25, 52, 102),
            Color.rgb(51, 78, 127),
            Color.rgb(76, 103, 153),
            Color.rgb(102, 129, 178),
            Color.rgb(127, 154, 204),
            Color.rgb(153, 180, 229)

    };
}
