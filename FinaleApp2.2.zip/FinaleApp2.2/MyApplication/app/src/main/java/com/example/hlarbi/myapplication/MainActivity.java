package com.example.hlarbi.myapplication;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.ResponseHandlerInterface;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.entity.mime.Header;

public class MainActivity extends AppCompatActivity {
    static JSONObject jsonObj = null;
    Button button;
    String latlog = "48.856614;2.3522219";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);


        int i=0;
        while (i<2) {
        AsyncHttpClient client = new AsyncHttpClient();
        client.get("https://api.waqi.info/feed/geo:41.390205;2.154007/?token=c7cb1dd08fbca3cd163693d2d79efd9660a8e9a0&lat&lng&optional", null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {
                byte[] data = responseBody;
                String json = new String(data);

                try {
                    jsonObj = new JSONObject(json);
                } catch (JSONException e) {
                    e.printStackTrace();

                }
            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

            }

        });
        i++
        ; }
    }       /*
public JSONObject responseJ() {

    AsyncHttpClient client = new AsyncHttpClient();


    client.get("https://api.waqi.info/feed/geo:"+"52.489471;-1.898575"+"/?token=c7cb1dd08fbca3cd163693d2d79efd9660a8e9a0&lat&lng&optional",
            null, new JsonHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, JSONObject response) {
                    try {
                        data = response.getJSONObject("data");
                        String aqinumber = data.get("aqi").toString();
                        JSONObject iaqui = data.getJSONObject("iaqi");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });


    return data;}*/
}

